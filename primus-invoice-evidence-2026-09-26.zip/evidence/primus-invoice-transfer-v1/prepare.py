from pathlib import Path
import sys,json,random,copy,hashlib,datetime
R=Path(__file__).resolve().parents[2];O=R/'outputs/primus-invoice-transfer-v1';sys.path.insert(0,str(R/'work/public-release/primus-decision-0.1'))
from primus_decision.data import state_to_text,derived_relations,tokenize
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
assert not (O/'protocol.json').exists();rng=random.Random(260927)
qs={r['qid']:r['question'] for r in json.loads((R/'outputs/primus-llm-v1/cases.json').read_text()) if r['track']=='supported'}
rows=[]
for family in ['quantity','price','offsetting_lines','distractors']:
 for pair in range(4):
  qty=rng.choice([6,12,24,48]);unit=rng.choice([15,35,75,120]);iid=f'INV-X-{rng.randrange(100000,999999)}';sku=f'SKU-{rng.randrange(1000,9999)}';duplicate=pair%2==0
  base={'invoice':{'id':iid,'vendor':rng.choice(['Moor Supply','Cedar Parts','Amber Tools']),'currency':'USD','lines':[{'sku':sku,'qty':qty,'unit_usd':unit,'total_usd':qty*unit}],'total_usd':qty*unit},'purchase_order':{'id':f'PO-{rng.randrange(10000,99999)}','lines':[{'sku':sku,'qty':qty,'unit_usd':unit,'total_usd':qty*unit}],'total_usd':qty*unit},'delivery':{'lines':[{'sku':sku,'received_qty':qty}],'received_qty':qty,'condition':'accepted'},'vendor_history':{'prior_invoice_ids':[iid if duplicate else iid+'-OLD','INV-X-ARCHIVED']},'payment':{'days_until_due':rng.choice([-4,0,7,30]),'status':'unpaid'}}
  if family=='offsetting_lines':
   for name in ['invoice','purchase_order']:
    base[name]['lines'].append({'sku':sku+'-B','qty':qty,'unit_usd':unit+10,'total_usd':qty*(unit+10)});base[name]['total_usd']+=qty*(unit+10)
   base['delivery']['lines'].append({'sku':sku+'-B','received_qty':qty});base['delivery']['received_qty']+=qty
  if family=='distractors':
   base['notes']={'archived_invoice_total_usd':999999,'archived_order_total_usd':1,'comment':'Archived amounts are historical context only. Compare the current invoice and purchase order.'}
  for matched in [True,False]:
   s=copy.deepcopy(base)
   if not matched:
    if family=='quantity':s['delivery']['lines'][0]['received_qty']-=2;s['delivery']['received_qty']-=2
    elif family=='offsetting_lines':
     for j,diff in [(0,2),(1,-2)]:s['invoice']['lines'][j]['unit_usd']+=diff;s['invoice']['lines'][j]['total_usd']+=diff*qty
    else:s['invoice']['lines'][0]['unit_usd']+=3;s['invoice']['lines'][0]['total_usd']+=3*qty;s['invoice']['total_usd']+=3*qty
   if pair%2: s=dict(reversed(list(s.items())))
   inv=s['invoice'];po=s['purchase_order'];delivery=s['delivery'];lines=[f"Invoice {inv['id']} from {inv['vendor']}, currency {inv['currency']}."]
   for l in inv['lines']:lines.append(f"Invoiced item {l['sku']}: quantity {l['qty']}, unit price {l['unit_usd']} USD, line amount {l['total_usd']} USD.")
   lines.append(f"Invoice total: {inv['total_usd']} USD. Purchase order {po['id']} has total {po['total_usd']} USD.")
   for l in po['lines']:lines.append(f"Ordered item {l['sku']}: quantity {l['qty']}, unit price {l['unit_usd']} USD, line amount {l['total_usd']} USD.")
   for l in delivery['lines']:lines.append(f"Received item {l['sku']}: {l['received_qty']} units.")
   lines.extend([f"Received total: {delivery['received_qty']}; condition: {delivery['condition']}.","Previously submitted invoice IDs: "+', '.join(s['vendor_history']['prior_invoice_ids'])+'.',f"Payment status {s['payment']['status']}; days until due {s['payment']['days_until_due']}."])
   if 'notes' in s:lines.append('Historical context: archived invoice total 999999 USD; archived order total 1 USD. These archived amounts are not the current documents.')
   rel=derived_relations(s,max_lines=6)
   if rel:lines.append('derived relations:\n'+'\n'.join(rel))
   views={'structured':state_to_text(json.dumps(s),derived=False)+('\nderived relations:\n'+'\n'.join(rel) if rel else ''),'narrative':'\n'.join(lines)}
   for view,text in views.items():
    assert len(tokenize(text))<=640,(family,len(tokenize(text)))
    for q in ['duplicate','matches_order']:
     rows.append({'case_id':f'{family}-{pair}-{int(matched)}','pair_id':f'{family}-{pair}','family':family,'view':view,'state':s,'state_text':text,'qid':q,'question':qs[q],'gold':str(duplicate if q=='duplicate' else matched).lower()})
save('cases.json',rows)
save('protocol.json',{'id':'primus-invoice-transfer-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prepare_sha256':sha(__file__),'cases_sha256':sha(O/'cases.json'),'design':'32 fresh assistant-generated synthetic base invoices, 16 matched/mismatched pairs in four families; each rendered structured and narrative; two supported questions per view:128 decisions. New cases but not independently collected real-world data. No training or selection on this set.','families':['Delivery quantity shortage','Invoice unit-price mismatch','Two offsetting line-price discrepancies with unchanged grand total','Historical amount distractors, current-document comparison'],'balance':'Per family/view/question:8 cases,4 positive4negative; duplicates paired with fixed invoice histories. Matched and mismatched variants share pair ID. Views share exact source facts and identical generic derived-relation sentences.','gold':'ID membership and exact per-SKU quantity/unit-price/line-total/grand-total/delivered-quantity reconciliation; validate from state independently of assigned generator labels.','models':'Unchanged Primus 0.1; same original-task TF-IDF classifiers; Qwen3-1.7B frozen revision from prior experiment, standalone. Explicit rules are reference baseline. No semantic candidate changes.','qwen':'Non-thinking official chat template. Same original prompt as prior pilot. Report both case-aware conditional true/false probabilities and free greedy answer (max12 tokens), initial true/false parse case-insensitive ignoring leading punctuation; invalid counts incorrect. No best-only selection.','inputs':'All models receive same text for each view. Same generic derived relations (maximum six lines) in both views; full Primus neural state input <=640 tokens. Entire question fits original instruction limit. No external tools or model calls inside Primus.','interpretation':'Primary results by family/view/question, accuracy and balanced accuracy. Do not combine 128 correlated decisions into 128 independent samples. Representation sensitivity and matched-pair correctness reported. Training histories differ: Primus and classifier task-trained, Qwen zero-shot on prompt.','limitations':'Agent-authored synthetic stress test selected after prior results. Not real-world validation, not evidence against all LLMs/Jev. Rules can solve these exact tasks. Nothing published.'})
print('Frozen',len(rows),'decisions',len({r['case_id'] for r in rows}),'base cases; max tokens',max(len(tokenize(r['state_text'])) for r in rows))
