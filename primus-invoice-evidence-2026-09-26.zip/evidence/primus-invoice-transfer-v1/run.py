from pathlib import Path
import sys,json,hashlib,re,gc,time
import numpy as np,torch
R=Path(__file__).resolve().parents[2];O=R/'outputs/primus-invoice-transfer-v1';PREV=R/'outputs/primus-llm-v1';RELEASE=R/'work/public-release/primus-decision-0.1';sys.path.insert(0,str(RELEASE));torch.set_num_threads(2)
from primus_decision.predict import PrimusDecision,request_to_case
from primus_decision.data import state_to_text
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
rows=json.loads((O/'cases.json').read_text());proto=json.loads((O/'protocol.json').read_text());assert sha(O/'cases.json')==proto['cases_sha256'];mode=sys.argv[1];assert not (O/f'{mode}-completion.json').exists()
def rule(r):
 s=r['state']
 if r['qid']=='duplicate':return s['invoice']['id'] in s['vendor_history']['prior_invoice_ids']
 i={l['sku']:l for l in s['invoice']['lines']};p={l['sku']:l for l in s['purchase_order']['lines']};d={l['sku']:l['received_qty'] for l in s['delivery']['lines']}
 return set(i)==set(p)==set(d) and s['invoice']['total_usd']==s['purchase_order']['total_usd'] and all(all(i[k][f]==p[k][f] for f in ['qty','unit_usd','total_usd']) and d[k]==p[k]['qty'] for k in p)
for r in rows:assert str(rule(r)).lower()==r['gold']
results=[]
def add(r,model,p=None,pred=None,raw=None):
 if p is not None:pred='true' if p>=.5 else 'false'
 results.append({k:r[k] for k in ['case_id','pair_id','family','view','qid','gold']}|{'model':model,'p_true':p,'prediction':pred,'raw_output':raw})
meta={'script_sha256':sha(__file__),'torch':torch.__version__,'started_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()};save(f'{mode}-execution.json',meta)
if mode=='primus':
 import pyarrow.parquet as pq
 from sklearn.pipeline import make_pipeline
 from sklearn.feature_extraction.text import TfidfVectorizer
 from sklearn.linear_model import LogisticRegression
 members=[PrimusDecision.load(RELEASE/f'model/member{i}') for i in range(2)]
 for r in rows:
  c=request_to_case(r['state_text'],{r['qid']:r['question']},'invoice_processing',derived=False);c.case_id=r['case_id']+'-'+r['view']
  with torch.no_grad():
   ps=[]
   for m in members:
    _,batch=m.batcher.make([c]);ps.append(float(m.model(batch).exp()[0,1]))
  add(r,'primus_0.1',sum(ps)/2);add(r,'explicit_rules',float(rule(r)))
 del members,m;gc.collect()
 train=pq.read_table(R/'work/primus-semantic-v1/train.parquet').to_pylist();fit=[r for r in train if r['workflow']=='invoice_processing' and int(hashlib.sha256(r['id'].encode()).hexdigest(),16)%100>=20]
 classifiers={}
 for q in ['duplicate','matches_order']:
  model=make_pipeline(TfidfVectorizer(ngram_range=(1,2),sublinear_tf=True),LogisticRegression(C=1,max_iter=2000,random_state=0));model.fit([state_to_text(r['state']) for r in fit],[str(json.loads(r['gold'])[q]['label']).lower() for r in fit]);classifiers[q]=model
 for r in rows:
  m=classifiers[r['qid']];add(r,'tfidf',float(m.predict_proba([r['state_text']])[0,list(m.classes_).index('true')]))
else:
 assert mode=='llm';sys.path.append(str(R/'work/primus-llm-v1/deps'))
 from transformers import AutoTokenizer,AutoModelForCausalLM
 folder=R/'work/primus-llm-v1/qwen';source=json.loads((PREV/'llm-runtime.json').read_text());assert all(sha(folder/n)==h for n,h in source['weights'].items())
 t=AutoTokenizer.from_pretrained(folder,local_files_only=True);m=AutoModelForCausalLM.from_pretrained(folder,local_files_only=True,torch_dtype=torch.float16,attn_implementation='sdpa').to('mps').eval();ids={}
 for k in ['false','true']:
  z=[t.encode(v,add_special_tokens=False) for v in [k,k.capitalize()]];assert all(len(a)==1 for a in z);ids[k]=[a[0] for a in z]
 for index,r in enumerate(rows):
  prompt='Read the record and answer the question. Choose exactly true or false.\n\nRecord:\n'+r['state_text']+'\n\nQuestion:\n'+r['question']['instructions']+'\n\nAnswer meanings:\n'+json.dumps(r['question'].get('criteria',{'false':'No.','true':'Yes.'}))+'\n\nAnswer:'
  text=t.apply_chat_template([{'role':'user','content':prompt}],tokenize=False,add_generation_prompt=True,enable_thinking=False);x=t(text,return_tensors='pt').to('mps');assert x.input_ids.shape[1]<=4096
  with torch.inference_mode():
   z=m(**x,use_cache=False,logits_to_keep=1).logits[0,-1].float();v=torch.stack([torch.logsumexp(z[ids[k]],0) for k in ['false','true']]).softmax(0);p=float(v[1].cpu());assert np.isfinite(p)
   y=m.generate(**x,max_new_tokens=12,do_sample=False,pad_token_id=t.eos_token_id)
  raw=t.decode(y[0,x.input_ids.shape[1]:],skip_special_tokens=True);match=re.match(r'^\W*(true|false)\b',raw,re.I);add(r,'qwen_case_aware',p);add(r,'qwen_free',pred=match.group(1).lower() if match else None,raw=raw)
  if index%16==0:print('Completed',index+1,'of',len(rows),flush=True)
  save('progress.json',{'completed':index+1,'total':len(rows)});save('llm-predictions.json',results)
 meta.update({'source':source['source'],'weights':source['weights'],'dtype':'float16','device':'mps'})
save(f'{mode}-predictions.json',results);save(f'{mode}-completion.json',meta|{'instances':len(rows),'predictions':len(results)});print('Completed',mode,flush=True)
