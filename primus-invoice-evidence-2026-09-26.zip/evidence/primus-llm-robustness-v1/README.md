# Qwen answer-format audit

Six answer formats were evaluated on the same 64 supported-question instances. The original scoring replay reproduced all probabilities and labels exactly. These are retrospective diagnostics on the pilot cases.

| Condition | Question | Correct | Invalid |
|---|---|---:|---:|
| letters_A_false | duplicate | 16/32 | 0 |
| letters_A_false | matches_order | 8/32 | 0 |
| letters_A_true | duplicate | 16/32 | 0 |
| letters_A_true | matches_order | 8/32 | 0 |
| original_case_aliases | duplicate | 17/32 | 0 |
| original_case_aliases | matches_order | 8/32 | 0 |
| original_free_generation | duplicate | 14/32 | 3 |
| original_free_generation | matches_order | 8/32 | 0 |
| original_lowercase_replay | duplicate | 19/32 | 0 |
| original_lowercase_replay | matches_order | 8/32 | 0 |
| yes_no_aliases | duplicate | 20/32 | 0 |
| yes_no_aliases | matches_order | 8/32 | 0 |

Read [the complete study](../../README.md) and [reproduction guide](../README.md).
