from pathlib import Path
import sys,json,datetime,hashlib,re,time,collections
import torch,numpy as np
ROOT=Path(__file__).resolve().parents[2];W=ROOT/'work/primus-llm-robustness-v1';O=ROOT/'outputs/primus-llm-robustness-v1';PREV=ROOT/'outputs/primus-llm-v1';MODEL=ROOT/'work/primus-llm-v1/qwen'
sys.path.append(str(ROOT/'work/primus-llm-v1/deps'))
from transformers import AutoTokenizer,AutoModelForCausalLM
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
assert not (O/'protocol.json').exists()
rows=[r for r in json.loads((PREV/'cases.json').read_text()) if r['track']=='supported'];source=json.loads((PREV/'llm-runtime.json').read_text());assert all(sha(MODEL/n)==h for n,h in source['weights'].items())
tok=AutoTokenizer.from_pretrained(MODEL,local_files_only=True)
variants={'false':['false','False'],'true':['true','True'],'no':['no','No'],'yes':['yes','Yes'],'A':['A'],'B':['B']};ids={}
for k,ss in variants.items():
 ids[k]=[]
 for s in ss:
  t=tok.encode(s,add_special_tokens=False);assert len(t)==1;ids[k].append(t[0])
assert len(set(x for group in ids.values() for x in group))==sum(map(len,ids.values()))
protocol={'id':'primus-llm-answer-format-robustness-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script_sha256':sha(__file__),'source_cases_sha256':sha(PREV/'cases.json'),'source_predictions_sha256':sha(PREV/'llm-predictions.json'),'model':source['source'],'weights':source['weights'],'sample':'All 64 supported-question instances on the 32 previously evaluated invoices. Retrospective diagnostic; not fresh test evidence. Original data and results remain intact.','conditions':['Original prompt, original lowercase-only true/false scoring replay','Same original prompt, sum probability of lowercase and capitalized True/False token aliases','Same original prompt, free greedy generation max12 new tokens; parse initial true/false ignoring case and leading punctuation; invalid outputs count incorrect','Neutral yes/no prompt; sum lowercase and capitalized yes/no token aliases','A/B answer prompt: A=false,B=true','Identical A/B prompt with meanings exchanged: A=true,B=false'],'selection':'Run and report all conditions. No best-only headline, no prompt tuning, no model training or checkpoint selection. Letter variants paired on every example.','mode':'Non-thinking official chat template; MPS float16, two CPU threads; same flattened state and question/criteria content in all conditions; original generation greedy, other conditions conditional next-token probabilities. Labels and category names change only as prescribed.','token_aliases':ids,'metrics':'Per condition and question accuracy (invalid free outputs incorrect), true answer counts, invalid counts; paired disagreement across formats; original score replay differences. Primus comparison reuses unchanged supported-question predictions.'}
save('protocol.json',protocol)
torch.set_num_threads(2);m=AutoModelForCausalLM.from_pretrained(MODEL,local_files_only=True,torch_dtype=torch.float16,attn_implementation='sdpa').to('mps').eval();results=[];prompts=[]
def input_for(p):
 text=tok.apply_chat_template([{'role':'user','content':p}],tokenize=False,add_generation_prompt=True,enable_thinking=False);x=tok(text,return_tensors='pt').to('mps');assert x.input_ids.shape[1]<=4096;return x
def forward(p):
 x=input_for(p)
 with torch.inference_mode():z=m(**x,use_cache=False,logits_to_keep=1).logits[0,-1].float()
 return x,z

def prob(z,f,t):
 a=torch.logsumexp(z[f],0);b=torch.logsumexp(z[t],0);v=float(torch.stack([a,b]).softmax(0)[1].cpu());assert np.isfinite(v);return v

def add(r,c,p=None,pred=None,raw=None):
 if p is not None:pred='true' if p>=.5 else 'false'
 results.append({'case_id':r['case_id'],'qid':r['qid'],'gold':r['gold'],'condition':c,'p_true':p,'prediction':pred,'raw_output':raw})
for i,r in enumerate(rows):
 instruction=r['question']['instructions'];crit=r['question'].get('criteria',{'false':'No.','true':'Yes.'});record=r['state_text']
 original='Read the record and answer the question. Choose exactly true or false.\n\nRecord:\n'+record+'\n\nQuestion:\n'+instruction+'\n\nAnswer meanings:\n'+json.dumps(crit)+'\n\nAnswer:'
 x,z=forward(original);add(r,'original_lowercase_replay',prob(z,[ids['false'][0]],[ids['true'][0]]));add(r,'original_case_aliases',prob(z,ids['false'],ids['true']))
 with torch.inference_mode():y=m.generate(**x,max_new_tokens=12,do_sample=False,pad_token_id=tok.eos_token_id)
 raw=tok.decode(y[0,x.input_ids.shape[1]:],skip_special_tokens=True);match=re.match(r'^\W*(true|false)\b',raw,re.I);add(r,'original_free_generation',pred=match.group(1).lower() if match else None,raw=raw)
 yn='Evaluate the question using only the record. Answer Yes if the true definition applies and No if the false definition applies.\n\nRecord:\n'+record+'\n\nQuestion:\n'+instruction+'\n\nDefinitions:\n'+json.dumps(crit)+'\n\nAnswer Yes or No:'
 _,z=forward(yn);add(r,'yes_no_aliases',prob(z,ids['no'],ids['yes']))
 for swap in [False,True]:
  a,b=('true','false') if swap else ('false','true');letter='Read the record and select the correct answer to the question.\n\nRecord:\n'+record+'\n\nQuestion:\n'+instruction+'\n\nOptions:\nA: '+a+' — '+crit[a]+'\nB: '+b+' — '+crit[b]+'\n\nRespond with A or B only:'
  _,z=forward(letter);add(r,'letters_A_true' if swap else 'letters_A_false',prob(z,ids['B'] if swap else ids['A'],ids['A'] if swap else ids['B']))
  prompts.append({'case_id':r['case_id'],'qid':r['qid'],'condition':'letters_A_true' if swap else 'letters_A_false','prompt_sha256':hashlib.sha256(letter.encode()).hexdigest()})
 for c,p in [('original',original),('yes_no',yn)]:prompts.append({'case_id':r['case_id'],'qid':r['qid'],'condition':c,'prompt_sha256':hashlib.sha256(p.encode()).hexdigest()})
 save('progress.json',{'instances_completed':i+1,'instances_total':len(rows)});save('predictions.json',results)
 if i%8==0:print('Completed',i+1,'of',len(rows),flush=True)
save('prompt-hashes.json',prompts)
metrics=[]
for c in sorted({r['condition'] for r in results}):
 for q in ['duplicate','matches_order']:
  rs=[r for r in results if r['condition']==c and r['qid']==q];metrics.append({'condition':c,'question':q,'n':len(rs),'correct':sum(r['prediction']==r['gold'] for r in rs),'true_predictions':sum(r['prediction']=='true' for r in rs),'invalid':sum(r['prediction'] is None for r in rs)})
save('metrics.json',metrics)
old={(r['case_id'],r['qid']):r for r in json.loads((PREV/'llm-predictions.json').read_text()) if r['track']=='supported'}
save('replay-check.json',{'max_probability_difference':max(abs(r['p_true']-old[(r['case_id'],r['qid'])]['p_true']) for r in results if r['condition']=='original_lowercase_replay'),'label_changes':sum(r['prediction']!=old[(r['case_id'],r['qid'])]['prediction'] for r in results if r['condition']=='original_lowercase_replay')})
save('completion.json',{'conditions':6,'instances':len(rows),'predictions':len(results),'torch':torch.__version__,'device':'mps','dtype':'float16'});print(json.dumps(metrics,indent=2),flush=True)
