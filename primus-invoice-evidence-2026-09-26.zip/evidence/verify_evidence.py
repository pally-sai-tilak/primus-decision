"""Audit published predictions and checksums; no model libraries or network required."""
from pathlib import Path
from collections import defaultdict
import hashlib
import json
import math
import statistics

ROOT = Path(__file__).resolve().parent
load = lambda folder, name: json.loads((ROOT / folder / name).read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
PILOT = 'primus-llm-v1'
AUDIT = 'primus-llm-robustness-v1'
TRANSFER = 'primus-invoice-transfer-v1'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def near(a, b):
    return math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12)


def verify_hashes():
    count = 0
    for line in (ROOT / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  ', 1)
        require(sha(ROOT / name) == digest, f'Checksum mismatch: {name}')
        count += 1
    for folder in [PILOT, AUDIT, TRANSFER]:
        export = load(folder, 'EXPORT.json')
        original = load(folder, 'ORIGINAL_SHA256.json')
        for name, digest in export['exported_file_sha256'].items():
            require(sha(ROOT / folder / name) == digest, f'Export mismatch: {folder}/{name}')
        for name in export['preserved_original_files']:
            require(sha(ROOT / folder / name) == original[name], f'Original record changed: {folder}/{name}')
        for name in original:
            if name.endswith('.json'):
                require(name in export['preserved_original_files'], f'Missing original JSON: {folder}/{name}')
    return count


def pilot():
    records = load(PILOT, 'primus-predictions.json') + load(PILOT, 'llm-predictions.json')
    cases = load(PILOT, 'cases.json')
    require(len(cases) == 192 and len({r['case_id'] for r in cases}) == 32, 'Pilot case counts')
    gold = {(r['case_id'], r['track'], r['qid']): r['gold'] for r in cases}
    keys = {(r['case_id'], r['track'], r['qid'], r['model']) for r in records}
    require(len(keys) == len(records) == 960, 'Pilot prediction counts or duplicate records')
    for r in records:
        require(r['gold'] == gold[r['case_id'], r['track'], r['qid']], 'Pilot gold mismatch')
    for m in load(PILOT, 'metrics.json'):
        group = [r for r in records if (r['track'], r['qid'], r['model']) == (m['track'], m['qid'], m['model'])]
        answered = [r for r in group if r['prediction'] is not None]
        require(len(group) == m['total'] and len(answered) == m['answered'], 'Pilot denominator mismatch')
        if answered:
            correct = sum(r['prediction'] == r['gold'] for r in answered)
            balanced = statistics.mean(statistics.mean(r['prediction'] == label for r in answered if r['gold'] == label) for label in ['true', 'false'])
            brier = statistics.mean((r['p_true'] - (r['gold'] == 'true')) ** 2 for r in answered)
            require(correct == m['correct'] and near(correct / len(answered), m['accuracy']), 'Pilot accuracy mismatch')
            require(near(balanced, m['balanced_accuracy']) and near(brier, m['brier']), 'Pilot probability metrics mismatch')
    return records


def audit(pilot_records):
    records = load(AUDIT, 'predictions.json')
    require(len(records) == 384, 'Audit prediction count')
    require(len({(r['case_id'], r['qid'], r['condition']) for r in records}) == 384, 'Duplicate audit records')
    for m in load(AUDIT, 'metrics.json'):
        g = [r for r in records if (r['condition'], r['qid']) == (m['condition'], m['question'])]
        for key, actual in [('n', len(g)), ('correct', sum(r['prediction'] == r['gold'] for r in g)), ('invalid', sum(r['prediction'] is None for r in g)), ('true_predictions', sum(r['prediction'] == 'true' for r in g))]:
            require(actual == m[key], f'Audit {key} mismatch')
    old = {(r['case_id'], r['qid']): r for r in pilot_records if r['model'] == 'qwen3_1.7b' and r['track'] == 'supported'}
    replay = [r for r in records if r['condition'] == 'original_lowercase_replay']
    difference = max(abs(r['p_true'] - old[r['case_id'], r['qid']]['p_true']) for r in replay)
    changes = sum(r['prediction'] != old[r['case_id'], r['qid']]['prediction'] for r in replay)
    check = load(AUDIT, 'replay-check.json')
    require(difference == check['max_probability_difference'] == 0 and changes == check['label_changes'] == 0, 'Replay mismatch')


def transfer():
    cases = load(TRANSFER, 'cases.json')
    require(len(cases) == 128 and len({r['case_id'] for r in cases}) == 32, 'Transfer case counts')
    records = load(TRANSFER, 'primus-predictions.json') + load(TRANSFER, 'llm-predictions.json')
    require(len(records) == len({(r['case_id'], r['view'], r['qid'], r['model']) for r in records}) == 640, 'Transfer prediction counts')
    gold = {(r['case_id'], r['view'], r['qid']): r['gold'] for r in cases}
    for r in records:
        require(r['gold'] == gold[r['case_id'], r['view'], r['qid']], 'Transfer gold mismatch')
    for m in load(TRANSFER, 'metrics.json'):
        group = [r for r in records if (m['family'] == 'all' or r['family'] == m['family']) and (r['view'], r['qid'], r['model']) == (m['view'], m['question'], m['model'])]
        correct = sum(r['prediction'] == r['gold'] for r in group)
        require(len(group) == m['n'] and correct == m['correct'] and near(correct / len(group), m['accuracy']), 'Transfer accuracy mismatch')
        require(sum(r['gold'] == 'true' for r in group) * 2 == len(group), 'Transfer class balance')
        require(sum(r['prediction'] is None for r in group) == m['invalid'], 'Transfer invalid count')
    for m in load(TRANSFER, 'matched-pairs.json'):
        pairs = defaultdict(list)
        for r in records:
            if (r['model'], r['view'], r['qid']) == (m['model'], m['view'], 'matches_order'):
                pairs[r['pair_id']].append(r)
        require(len(pairs) == m['pairs'] == 16 and all(len(g) == 2 for g in pairs.values()), 'Pair counts')
        correct = sum(all(r['prediction'] == r['gold'] for r in g) for g in pairs.values())
        require(correct == m['both_members_correct'], 'Pair accuracy mismatch')
    lookup = {(m['view'], m['question'], m['model']): m['correct'] for m in load(TRANSFER, 'metrics.json') if m['family'] == 'all'}
    require(lookup['structured', 'matches_order', 'primus_0.1'] == 26, 'Structured headline')
    require(lookup['narrative', 'matches_order', 'primus_0.1'] == 17, 'Narrative headline')


if __name__ == '__main__':
    checked = verify_hashes()
    pilot_records = pilot()
    audit(pilot_records)
    transfer()
    print(f'PASS: {checked} checksums; preserved original JSON; pilot, audit and transfer metrics; class balance; paired results; exact Qwen replay.')
