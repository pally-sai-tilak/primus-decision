import urllib.request,json,hashlib
from pathlib import Path
w=Path(__file__).resolve().parent; d=w/'qwen';d.mkdir(exist_ok=True)
meta=json.load(urllib.request.urlopen('https://huggingface.co/api/models/Qwen/Qwen3-1.7B/revision/70d244cc86ccca08cf5af4e1e306ecf908b1ad5e'));rev=meta['sha'];assert rev=='70d244cc86ccca08cf5af4e1e306ecf908b1ad5e';(w/'qwen-source.json').write_text(json.dumps({'model':'Qwen/Qwen3-1.7B','revision':rev},indent=2))
for n in [f['rfilename'] for f in meta['siblings'] if f['rfilename'] in ['config.json','generation_config.json','tokenizer.json','tokenizer_config.json','model.safetensors.index.json'] or f['rfilename'].endswith('.safetensors')]:
 p=d/n
 if not p.exists():
  print('Downloading',n,flush=True)
  with urllib.request.urlopen(f'https://huggingface.co/Qwen/Qwen3-1.7B/resolve/{rev}/{n}',timeout=120) as r,(d/(n+'.part')).open('wb') as f:
   while True:
    b=r.read(4*1024*1024)
    if not b:break
    f.write(b)
  (d/(n+'.part')).rename(p)
 print(n,p.stat().st_size,flush=True)
