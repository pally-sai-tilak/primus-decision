# Invoice pilot: supported decisions and rewording

Primus Decision 0.1 answered 32/32 reconciliation questions correctly, retaining the score after rewording. The 32 synthetic invoices produce six related answers each. Reconciliation labels are 8 true / 24 false; other questions are balanced.

| Track | Question | System | Answered | Correct |
|---|---|---|---:|---:|
| new | past_due | explicit_rules | 32/32 | 32 |
| new | past_due | public | 0/32 | — |
| new | past_due | qwen3_1.7b | 32/32 | 16 |
| new | past_due | semantic | 32/32 | 17 |
| new | past_due | tfidf | 0/32 | — |
| new | received_less | explicit_rules | 32/32 | 32 |
| new | received_less | public | 0/32 | — |
| new | received_less | qwen3_1.7b | 32/32 | 16 |
| new | received_less | semantic | 32/32 | 14 |
| new | received_less | tfidf | 0/32 | — |
| reworded | duplicate | explicit_rules | 32/32 | 32 |
| reworded | duplicate | public | 32/32 | 18 |
| reworded | duplicate | qwen3_1.7b | 32/32 | 16 |
| reworded | duplicate | semantic | 32/32 | 18 |
| reworded | duplicate | tfidf | 32/32 | 16 |
| reworded | matches_order | explicit_rules | 32/32 | 32 |
| reworded | matches_order | public | 32/32 | 32 |
| reworded | matches_order | qwen3_1.7b | 32/32 | 8 |
| reworded | matches_order | semantic | 32/32 | 30 |
| reworded | matches_order | tfidf | 32/32 | 32 |
| supported | duplicate | explicit_rules | 32/32 | 32 |
| supported | duplicate | public | 32/32 | 18 |
| supported | duplicate | qwen3_1.7b | 32/32 | 19 |
| supported | duplicate | semantic | 32/32 | 18 |
| supported | duplicate | tfidf | 32/32 | 16 |
| supported | matches_order | explicit_rules | 32/32 | 32 |
| supported | matches_order | public | 32/32 | 32 |
| supported | matches_order | qwen3_1.7b | 32/32 | 8 |
| supported | matches_order | semantic | 32/32 | 30 |
| supported | matches_order | tfidf | 32/32 | 32 |

`public` is the released Primus 0.1 model; `semantic` is a separate private development candidate. Its recorded answers and scores are included, while its implementation and checkpoints stay private. `tfidf` is the original-task classifier; `explicit_rules` is the exact reference.

Read [the complete study](../../README.md) and [reproduction guide](../README.md).
