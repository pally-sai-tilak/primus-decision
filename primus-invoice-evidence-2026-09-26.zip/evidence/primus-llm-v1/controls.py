from pathlib import Path
import sys,json,torch
W=Path(__file__).resolve().parent;O=W.parents[1]/'outputs/primus-llm-v1';sys.path.append(str(W/'deps'))
from transformers import AutoTokenizer,AutoModelForCausalLM
torch.set_num_threads(2);t=AutoTokenizer.from_pretrained(W/'qwen',local_files_only=True);m=AutoModelForCausalLM.from_pretrained(W/'qwen',local_files_only=True,torch_dtype=torch.float16,attn_implementation='sdpa').to('mps').eval();ids=[t.encode(x,add_special_tokens=False)[0] for x in ['false','true']];out=[]
for q in ['Two is larger than one.','Two is smaller than one.','The word cat contains three letters.','The word cat contains seven letters.']:
 s=t.apply_chat_template([{'role':'user','content':'Answer exactly true or false: '+q}],tokenize=False,add_generation_prompt=True,enable_thinking=False);x=t(s,return_tensors='pt').to('mps')
 with torch.inference_mode():
  logits=m(**x,logits_to_keep=1).logits[0,-1].float();p=logits[ids].softmax(-1).cpu().tolist();y=m.generate(**x,max_new_tokens=12,do_sample=False,pad_token_id=t.eos_token_id)
 out.append({'question':q,'conditional_probs':p,'free_greedy_output':t.decode(y[0,x.input_ids.shape[1]:],skip_special_tokens=True)})
(O/'post-run-controls.json').write_text(json.dumps({'purpose':'Post-run implementation diagnostic, not a pre-registered performance result. No prompt or model change and no benchmark rerun.','controls':out},indent=2)+'\n');print(json.dumps(out),flush=True)
