# Public export runner: public model and baselines only; private candidate loader omitted.
from pathlib import Path
import sys,json,time,hashlib,copy,collections,gc
ROOT=Path(__file__).resolve().parents[2];W=ROOT/'work/primus-llm-v1';O=ROOT/'outputs/primus-llm-v1';R=ROOT/'work/public-release/primus-decision-0.1'
import numpy as np,torch
sys.path.insert(0,str(R));torch.set_num_threads(2)
from primus_decision.predict import PrimusDecision,request_to_case
from primus_decision.data import state_to_text
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
rows=json.loads((O/'cases.json').read_text());protocol=json.loads((O/'protocol.json').read_text());assert sha(O/'cases.json')==protocol['cases_sha256']
mode=sys.argv[1]
assert not (O/f'{mode}-predictions.json').exists()
# Check gold independently of generator factors.
for r in rows:
 s=r['state'];checks={'duplicate':s['invoice']['id'] in s['vendor_history']['prior_invoice_ids'],'matches_order':s['invoice']['total_usd']==s['purchase_order']['total_usd'] and s['delivery']['received_qty']==s['purchase_order']['lines'][0]['qty'] and s['invoice']['lines'][0]['qty']==s['purchase_order']['lines'][0]['qty'],'past_due':s['payment']['days_until_due']<0,'received_less':s['delivery']['received_qty']<s['purchase_order']['lines'][0]['qty']}
 assert r['gold']==str(checks[r['qid']]).lower()
records=[];meta={'script_sha256':sha(__file__),'torch':torch.__version__,'numpy':np.__version__}
def add(r,model,p,seconds=None,error=None):
 records.append({'case_id':r['case_id'],'track':r['track'],'qid':r['qid'],'gold':r['gold'],'model':model,'p_true':p,'prediction':None if p is None else ('true' if p>=.5 else 'false'),'seconds':seconds,'error':error})
if mode=='primus':
 from safetensors.torch import load_file
 from sklearn.pipeline import make_pipeline
 from sklearn.feature_extraction.text import TfidfVectorizer
 from sklearn.linear_model import LogisticRegression
 import pyarrow.parquet as pq
 for name in ['public']:
  members=[];total=0;size=0;hashes={}
  for i in range(2):
   m=PrimusDecision.load(R/f'model/member{i}')
   checkpoint=R/f'model/member{i}/model.safetensors'
   m.model.eval();members.append(m);total+=sum(p.numel() for p in m.model.parameters());size+=sum(p.numel()*p.element_size() for p in m.model.parameters());hashes[str(checkpoint.relative_to(ROOT))]=sha(checkpoint)
  meta[name]={'parameters':total,'parameter_bytes':size,'device':'CPU','dtype':'float32','checkpoint_hashes':hashes}
  for r in rows:
   c=request_to_case(r['state_text'],{r['qid']:r['question']},'invoice_processing',derived=False);c.case_id=r['case_id'];start=time.perf_counter()
   try:
    with torch.no_grad():
     ps=[]
     for m in members:
      _,b=m.batcher.make([c]);ps.append(float(m.model(b).exp()[0,1]))
    add(r,name,sum(ps)/2,time.perf_counter()-start)
   except ValueError as e:
    if name!='public' or r['track']!='new':raise
    add(r,name,None,error=str(e))
  del members,m;gc.collect()
 train=pq.read_table(ROOT/'work/primus-semantic-v1/train.parquet').to_pylist();fit=[r for r in train if r['workflow']=='invoice_processing' and int(hashlib.sha256(r['id'].encode()).hexdigest(),16)%100>=20];meta['classifier_fit_cases']=len(fit)
 classifiers={}
 for q in ['duplicate','matches_order']:
  model=make_pipeline(TfidfVectorizer(ngram_range=(1,2),sublinear_tf=True),LogisticRegression(C=1,max_iter=2000,random_state=0))
  model.fit([state_to_text(r['state']) for r in fit],[str(json.loads(r['gold'])[q]['label']).lower() for r in fit]);classifiers[q]=model
 for r in rows:
  if r['qid'] in classifiers:
   m=classifiers[r['qid']];t=time.perf_counter();p=m.predict_proba([r['state_text']])[0,list(m.classes_).index('true')];add(r,'tfidf',float(p),time.perf_counter()-t)
  else:add(r,'tfidf',None,error='No training labels for new question meaning')
  s=r['state']; rule={'duplicate':s['invoice']['id'] in s['vendor_history']['prior_invoice_ids'],'matches_order':s['invoice']['total_usd']==s['purchase_order']['total_usd'] and s['delivery']['received_qty']==s['purchase_order']['lines'][0]['qty'] and s['invoice']['lines'][0]['qty']==s['purchase_order']['lines'][0]['qty'],'past_due':s['payment']['days_until_due']<0,'received_less':s['delivery']['received_qty']<s['purchase_order']['lines'][0]['qty']}[r['qid']]
  add(r,'explicit_rules',float(rule))
else:
 assert mode=='llm'
 sys.path.append(str(W/'deps'))
 from transformers import AutoTokenizer,AutoModelForCausalLM
 device='mps' if torch.backends.mps.is_available() else 'cpu';dtype=torch.float16 if device=='mps' else torch.float32
 tok=AutoTokenizer.from_pretrained(W/'qwen',local_files_only=True);m=AutoModelForCausalLM.from_pretrained(W/'qwen',local_files_only=True,torch_dtype=dtype,attn_implementation='sdpa').to(device).eval()
 ids=[tok.encode(s,add_special_tokens=False) for s in ['false','true']];assert all(len(x)==1 for x in ids);choiceids=[x[0] for x in ids]
 meta.update({'source':json.loads((W/'qwen-source.json').read_text()),'device':device,'dtype':str(dtype),'parameters':sum(p.numel() for p in m.parameters()),'parameter_bytes':sum(p.numel()*p.element_size() for p in m.parameters()),'weights':{p.name:sha(p) for p in (W/'qwen').glob('*.safetensors')},'label_token_ids':choiceids,'max_prompt_tokens':0})
 for index,r in enumerate(rows):
  prompt='Read the record and answer the question. Choose exactly true or false.\n\nRecord:\n'+r['state_text']+'\n\nQuestion:\n'+r['question']['instructions']+'\n\nAnswer meanings:\n'+json.dumps(r['question'].get('criteria',{'false':'No.','true':'Yes.'}))+'\n\nAnswer:'
  text=tok.apply_chat_template([{'role':'user','content':prompt}],tokenize=False,add_generation_prompt=True,enable_thinking=False)
  inp=tok(text,return_tensors='pt');n=inp['input_ids'].shape[1];assert n<=4096;meta['max_prompt_tokens']=max(n,meta['max_prompt_tokens']);inp={k:v.to(device) for k,v in inp.items()}
  if device=='mps':torch.mps.synchronize()
  t=time.perf_counter()
  with torch.inference_mode():logits=m(**inp,use_cache=False,logits_to_keep=1).logits[0,-1,choiceids].float();p=float(logits.softmax(-1)[1].cpu())
  if device=='mps':torch.mps.synchronize()
  add(r,'qwen3_1.7b',p,time.perf_counter()-t)
  if index%16==0:print('Completed',index+1,'of',len(rows),flush=True)
  save('llm-progress.json',{'completed':index+1,'total':len(rows)})
 assert all(np.isfinite(r['p_true']) for r in records)
save(f'{mode}-predictions.json',records);save(f'{mode}-runtime.json',meta);print('Completed',mode,len(records),flush=True)
